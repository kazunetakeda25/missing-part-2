var class_language_1_1_lua_1_1_string_literal =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_string_literal.html#a7383657f3b7d1dff391d42c9128a5376", null ],
    [ "Text", "class_language_1_1_lua_1_1_string_literal.html#a88aab26838f3efb4df78666594f4cf61", null ]
];