var class_language_1_1_lua_1_1_lua_nil =
[
    [ "GetBooleanValue", "class_language_1_1_lua_1_1_lua_nil.html#a275cbefefbd9af69f14c3f38277d660c", null ],
    [ "GetTypeCode", "class_language_1_1_lua_1_1_lua_nil.html#a72e00584f47de6a4a7da693675edea52", null ],
    [ "ToString", "class_language_1_1_lua_1_1_lua_nil.html#aefd66bde0d4a00838720ae48b7b95c5d", null ],
    [ "Nil", "class_language_1_1_lua_1_1_lua_nil.html#a9cd186d9c704ead7e91b2147d0326d7d", null ],
    [ "Value", "class_language_1_1_lua_1_1_lua_nil.html#ab316cb4eb28590e860209a2d27e07035", null ]
];