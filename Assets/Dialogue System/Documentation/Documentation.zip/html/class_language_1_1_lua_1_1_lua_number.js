var class_language_1_1_lua_1_1_lua_number =
[
    [ "LuaNumber", "class_language_1_1_lua_1_1_lua_number.html#aed362d64ad84f6f265409bdd9d94ac08", null ],
    [ "GetTypeCode", "class_language_1_1_lua_1_1_lua_number.html#aad269fdfcb8f099623913f6460e3e034", null ],
    [ "ToString", "class_language_1_1_lua_1_1_lua_number.html#a977419225e3a8f425366b400f25d93c2", null ],
    [ "Number", "class_language_1_1_lua_1_1_lua_number.html#a52d8ed865cf005f5aecff8992fd00c25", null ],
    [ "Value", "class_language_1_1_lua_1_1_lua_number.html#a39f2a4ee78e8cd7ab010706a36c473b6", null ]
];