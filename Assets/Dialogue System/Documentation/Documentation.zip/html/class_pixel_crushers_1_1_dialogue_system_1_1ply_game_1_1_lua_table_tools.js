var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_lua_table_tools =
[
    [ "LuaTableName", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_lua_table_tools.html#acb32a1d1a396ac341f3fc25659ecaf13", null ]
];