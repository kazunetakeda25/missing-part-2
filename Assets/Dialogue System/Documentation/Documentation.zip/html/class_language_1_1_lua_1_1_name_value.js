var class_language_1_1_lua_1_1_name_value =
[
    [ "Name", "class_language_1_1_lua_1_1_name_value.html#adcaafed8482e765eb8d24dd992757f6e", null ]
];