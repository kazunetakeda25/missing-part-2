var class_language_1_1_lua_1_1_variable_arg =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_variable_arg.html#a22b43ff4f6af149e02494d188bae98a1", null ],
    [ "Name", "class_language_1_1_lua_1_1_variable_arg.html#af3741fa85e244c79218f95293fdf8d0c", null ]
];