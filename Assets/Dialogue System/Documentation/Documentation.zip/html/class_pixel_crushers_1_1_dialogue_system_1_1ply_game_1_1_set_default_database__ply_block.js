var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_default_database__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_default_database__ply_block.html#a56e31cab7a451ba490e4e09e22920c77", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_default_database__ply_block.html#aa954525727c42b78a2c8e2cfd7296900", null ],
    [ "database", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_default_database__ply_block.html#a40e80b2f02a76557f9e2eac0c93adf98", null ]
];