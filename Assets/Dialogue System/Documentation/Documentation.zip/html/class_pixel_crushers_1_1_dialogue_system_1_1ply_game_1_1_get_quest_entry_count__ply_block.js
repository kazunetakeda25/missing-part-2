var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry_count__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry_count__ply_block.html#ace127c08ef76fc72a37dbc79bc012ffb", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry_count__ply_block.html#ac09db70b31c9a264952faa42f2961fda", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry_count__ply_block.html#ad45ae5a26a99ff256649b3b15512b6a7", null ]
];