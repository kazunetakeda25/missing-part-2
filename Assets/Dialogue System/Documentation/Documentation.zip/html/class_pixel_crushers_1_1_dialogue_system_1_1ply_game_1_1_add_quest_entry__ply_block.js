var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest_entry__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest_entry__ply_block.html#a3ae47651cdeacb581b9f42e72a51462c", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest_entry__ply_block.html#a4e50c366c1f79f1803a3e1a51795a785", null ],
    [ "description", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest_entry__ply_block.html#a2329c23a8a0ebe05045cf85ec70da3d2", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest_entry__ply_block.html#a872d819d5e57c111a6124a0c721b11f1", null ]
];