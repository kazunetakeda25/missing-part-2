var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_lua_variable__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_lua_variable__ply_block.html#ac45691ef0cefccaa70fab3f4f1fb66d5", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_lua_variable__ply_block.html#a63fa9c2495fe656f7b9b0a7f9ebf8348", null ],
    [ "variableName", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_lua_variable__ply_block.html#a8241bc4fb34509c8f115ca96d9bedaa2", null ]
];