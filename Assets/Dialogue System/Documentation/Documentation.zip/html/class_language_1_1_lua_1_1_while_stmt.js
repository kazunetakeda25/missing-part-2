var class_language_1_1_lua_1_1_while_stmt =
[
    [ "Execute", "class_language_1_1_lua_1_1_while_stmt.html#ad77060c9462beb0b321dbe85234fe55e", null ],
    [ "Body", "class_language_1_1_lua_1_1_while_stmt.html#a16922058ae3936a64779d065a0c09492", null ],
    [ "Condition", "class_language_1_1_lua_1_1_while_stmt.html#a704c3e20ffbb2ceca411f3579167f418", null ]
];