var class_language_1_1_lua_1_1_function_name =
[
    [ "FullName", "class_language_1_1_lua_1_1_function_name.html#a9ccce0e0bc9c8f2edef0978528587d65", null ],
    [ "MethodName", "class_language_1_1_lua_1_1_function_name.html#a32330919796f6ae6dfbbbb7f5248d0cf", null ]
];