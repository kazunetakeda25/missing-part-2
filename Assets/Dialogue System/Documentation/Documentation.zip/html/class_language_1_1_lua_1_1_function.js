var class_language_1_1_lua_1_1_function =
[
    [ "Execute", "class_language_1_1_lua_1_1_function.html#ab99847bbbe707344592125fff6674938", null ],
    [ "Body", "class_language_1_1_lua_1_1_function.html#acfb2478a64ad37947fb6376f99ce4feb", null ],
    [ "Name", "class_language_1_1_lua_1_1_function.html#a4c51dfd0b1d23a85d418e938644373bd", null ]
];