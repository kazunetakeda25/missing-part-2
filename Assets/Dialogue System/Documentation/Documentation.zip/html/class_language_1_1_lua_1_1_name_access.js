var class_language_1_1_lua_1_1_name_access =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_name_access.html#a77c143e369ff5f4d7ec6050c02abcecb", null ],
    [ "Name", "class_language_1_1_lua_1_1_name_access.html#a69fb60d6f474c6b891536c1d60c75108", null ]
];