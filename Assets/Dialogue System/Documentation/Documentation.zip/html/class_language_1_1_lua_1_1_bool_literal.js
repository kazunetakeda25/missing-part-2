var class_language_1_1_lua_1_1_bool_literal =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_bool_literal.html#a5019f4bd658d974558611b392733fcd3", null ],
    [ "Text", "class_language_1_1_lua_1_1_bool_literal.html#a5ac4241c15ae9a872dc6cc6bfe6247c8", null ]
];