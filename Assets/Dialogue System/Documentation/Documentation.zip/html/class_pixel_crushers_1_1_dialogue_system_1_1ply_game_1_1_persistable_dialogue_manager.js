var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_persistable_dialogue_manager =
[
    [ "DeleteSaveData", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_persistable_dialogue_manager.html#acb56ab8e5f31651711b15c8a657195ea", null ],
    [ "DisablePersistence", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_persistable_dialogue_manager.html#a9a966f504ff7dae00e6a07eb91e7f225", null ],
    [ "Load", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_persistable_dialogue_manager.html#a674db34d5d7734297f769b5e0a0d62f8", null ],
    [ "Save", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_persistable_dialogue_manager.html#a38e1642330c562d4b146b5cc69393b5d", null ]
];