var class_language_1_1_lua_1_1_local_func =
[
    [ "Execute", "class_language_1_1_lua_1_1_local_func.html#a3be13df6b85dfdcf4963dcb2edb1fa66", null ],
    [ "Body", "class_language_1_1_lua_1_1_local_func.html#adddc16be1373c86fc2f9b5b7a14bc12c", null ],
    [ "Name", "class_language_1_1_lua_1_1_local_func.html#ae374e91ae277d7bc21af9fc0df4f7828", null ]
];