var class_language_1_1_lua_1_1_term =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_term.html#a54438b61685d02e4a97fb8538ef26b10", null ],
    [ "Simplify", "class_language_1_1_lua_1_1_term.html#a2b2f39b12455a7df13e0ff2bd323d078", null ]
];