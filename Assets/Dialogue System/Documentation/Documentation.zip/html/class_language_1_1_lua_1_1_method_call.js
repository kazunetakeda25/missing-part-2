var class_language_1_1_lua_1_1_method_call =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_method_call.html#a4178af4b4cddeb11c9c7d93eae9f793b", null ],
    [ "Args", "class_language_1_1_lua_1_1_method_call.html#a4d5a5250bbf2fb8d29b8f7b9c0a98898", null ],
    [ "Method", "class_language_1_1_lua_1_1_method_call.html#a4f9f56baead58f32b205748bca752025", null ]
];