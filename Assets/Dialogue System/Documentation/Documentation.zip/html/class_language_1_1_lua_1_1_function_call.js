var class_language_1_1_lua_1_1_function_call =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_function_call.html#a1f117730e39b50735147a4779bc29dc0", null ],
    [ "Args", "class_language_1_1_lua_1_1_function_call.html#a8f13a4cac6672c06378595916267518e", null ]
];