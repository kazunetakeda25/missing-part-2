var annotated =
[
    [ "Language", "namespace_language.html", "namespace_language" ],
    [ "PixelCrushers", "namespace_pixel_crushers.html", "namespace_pixel_crushers" ]
];