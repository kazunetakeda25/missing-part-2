var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_cancelled_event =
[
    [ "HandlerType", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_cancelled_event.html#a8ce67264ecb46911ac8e0fd4fbca893e", null ]
];