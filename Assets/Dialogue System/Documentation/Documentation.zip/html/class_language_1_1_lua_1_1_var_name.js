var class_language_1_1_lua_1_1_var_name =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_var_name.html#abc4852ba6c39ce69843677fa8ac2c3dc", null ],
    [ "Simplify", "class_language_1_1_lua_1_1_var_name.html#a44771db2dffff28af5b27f721d4b4b38", null ],
    [ "Name", "class_language_1_1_lua_1_1_var_name.html#ac324e4886796d04f6451a30bef81684d", null ]
];