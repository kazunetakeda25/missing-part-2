var class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu =
[
    [ "guiSkin", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a1a25e9357e7022a0d15dabcca00b4f86", null ],
    [ "player", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a5d986331595879c12e2ea0aa5eb49cf7", null ],
    [ "questLogWindow", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a9c40b8e03bf8aee56f757549a4376bfc", null ],
    [ "showCloseMenuButton", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a1fcc0af579d7cf31b1bc4ef7f39a34e5", null ],
    [ "showLoadGameButton", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#aac6dd97d3112a7310e7c3bebc0ad7ca7", null ],
    [ "showNewGameButton", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a63095041ffd84c8590b5caa6b3fa8e06", null ],
    [ "showQuestLogButton", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a6f1145365f6165dbf33b59ba23f0ce50", null ],
    [ "showSaveGameButton", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#ad04bd78c8307ddbf6c2af3d1a650d7e3", null ],
    [ "startingLevel", "class_pixel_crushers_1_1_dialogue_system_1_1_action_r_p_g2_d_1_1_example_menu.html#a0deddc08b03f49a93b46ed8b368975d7", null ]
];