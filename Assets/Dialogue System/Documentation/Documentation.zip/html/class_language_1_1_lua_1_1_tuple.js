var class_language_1_1_lua_1_1_tuple =
[
    [ "Create< T1, T2 >", "class_language_1_1_lua_1_1_tuple.html#a31c955023a31bb5a58948f5964cc7984", null ],
    [ "Create< T1, T2, T3 >", "class_language_1_1_lua_1_1_tuple.html#a732dc139dd781fadae012c75580b9338", null ]
];