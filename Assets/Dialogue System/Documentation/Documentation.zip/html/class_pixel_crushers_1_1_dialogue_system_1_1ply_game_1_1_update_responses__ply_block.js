var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_update_responses__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_update_responses__ply_block.html#a39517170700515e0feef8cfc17bdce1f", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_update_responses__ply_block.html#ae0f515ca762c4c517f37aed3e0ca9181", null ]
];