var class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls =
[
    [ "ClearSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a0f85acc3d554e3a18e62f198d8bd058b", null ],
    [ "HideContinueButton", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a052cc360c8ebfa46ab2363d8b6fd22fa", null ],
    [ "SetActorPortraitTexture", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#afca51ee0378701fac9a7bf4cf602bd74", null ],
    [ "SetSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a0bdb08b8ea1443e25ad71b42196fbc26", null ],
    [ "ShowSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a2a47b362e754e24093f8ae7d90fc2b60", null ],
    [ "currentSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a26867ee52c1dbf18f9e93e978326d479", null ],
    [ "HasText", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a8fbba81e36a766ee7b8f3c5ba6193f6b", null ]
];