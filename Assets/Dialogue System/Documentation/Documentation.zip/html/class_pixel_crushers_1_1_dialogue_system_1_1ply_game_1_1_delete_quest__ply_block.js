var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_delete_quest__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_delete_quest__ply_block.html#abe5098c64b132f31dd34b9d203fa8287", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_delete_quest__ply_block.html#a7472e45ebd18dcc2157fb5bd33769530", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_delete_quest__ply_block.html#ae6d36f9f5305468b21ab1115b55b1748", null ]
];