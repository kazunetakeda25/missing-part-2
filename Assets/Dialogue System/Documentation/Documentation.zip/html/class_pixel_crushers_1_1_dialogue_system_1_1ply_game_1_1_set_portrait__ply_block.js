var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_portrait__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_portrait__ply_block.html#aa662781067142b7ef6773a705e9c7637", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_portrait__ply_block.html#afbbf29239ec1ebecd8db07977bb4a881", null ],
    [ "actorName", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_portrait__ply_block.html#ad2de7c9bcc536a204c34649cbc5c39fa", null ],
    [ "portraitName", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_portrait__ply_block.html#a94130049040f0da746db154c39b80082", null ]
];