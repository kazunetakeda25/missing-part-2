var class_language_1_1_lua_1_1_group_expr =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_group_expr.html#a660aee5b1761489d023627d36ece47f7", null ],
    [ "Simplify", "class_language_1_1_lua_1_1_group_expr.html#ad87069946ebed5050a4e723627822efd", null ],
    [ "Expr", "class_language_1_1_lua_1_1_group_expr.html#a4af92b25341c9fb6f2d2ec8d80ef7576", null ]
];