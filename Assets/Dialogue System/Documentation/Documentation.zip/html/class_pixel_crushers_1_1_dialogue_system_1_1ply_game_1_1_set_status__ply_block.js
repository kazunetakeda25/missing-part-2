var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block.html#a26635b823ec914a01a4a48d853a7ade4", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block.html#a3bf892a24632a500beaa1a01e8db1b74", null ],
    [ "asset1", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block.html#a82dab31ec4a8d48b671858be1ffe0288", null ],
    [ "asset2", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block.html#a8af4c606752006354ca4540bc6800f5b", null ],
    [ "status", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_status__ply_block.html#aac35c9ddc1a54dd48e915a7d80005d65", null ]
];