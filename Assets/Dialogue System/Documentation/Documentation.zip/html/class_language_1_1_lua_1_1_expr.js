var class_language_1_1_lua_1_1_expr =
[
    [ "Evaluate", "class_language_1_1_lua_1_1_expr.html#ad6c9d729ae844bab4bb68d802ed0be25", null ],
    [ "Simplify", "class_language_1_1_lua_1_1_expr.html#ac7f83e3e3564cd72272afce77f138ae0", null ]
];